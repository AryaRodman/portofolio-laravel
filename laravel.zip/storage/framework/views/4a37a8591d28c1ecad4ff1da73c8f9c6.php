<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travis's Webpage</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="kepala">
        <h1>TRAVIS SCOTT</h1>
        
    </div>    
</header>

<main>
    <h2>Click below to find out complete biodata.</h2>
        <a href="/bio">
            <div class="id-button">
            <p>Travis's Bio</p>
            </div>
         
        </a>
        <a href="/pilantropi">
        <ul>
            <li>His Philantrophy</li>
        </ul>
        </a>
</main>

<footer>
    <div id="copirait">
        <div class="ket-footer">
            <p>Made By Arya</p>
            <p>Copyright | Arya Rodman.Inc 2023</p>
        </div>
        <p id="bigman">ARYA RODMAN.</p>
    </div>
</footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\curos\resources\views/landing/index.blade.php ENDPATH**/ ?>