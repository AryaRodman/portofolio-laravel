<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Here is his bio</title>
    <link rel="stylesheet" href="css/style2.css">
</head>
<body>
    <header>
        <div class="JOEDOEL">
            <h1>General information about Travis Scott</h1>
            <p>Jacques Bermon Webster II (born April 30, 1991), known professionally as Travis Scott (formerly stylized Travi$ Scott), is an American <br> rapper, singer, songwriter, and record producer. Throughout his career, Scott has achieved four number-one hits on the US Billboard Hot 100 chart, along with a total of over a hundred <br> charted songs. Over the course of his career, Scott has become a globally recognized artist and pop culture figure. Along with his highly publicized relationship with American media personality Kylie Jenner, Scott has collaborated with organizations  including Nike, Dior, and McDonald's. His Cactus Jack record label, founded in 2017, has signed artists including Don Toliver and Sheck Wes. Scott has gained notoriety for controversies <br> and legal issues regarding safety at his concerts. In November 2021, a mass-casualty crowd crush occurred during Scott's hometown performance at his annual Astroworld Festival, resulting in some condemnation of the artist. </p>
        </div>
    </header>
    <main>
        <div class="early-lv">
            <h1>Early life</h1>
            Now about his early life, Jacques B. Webster or Travis was born on April 30, 1991, in Houston, Texas. From ages one through six, Webster lived with his grandmother in South Park, Houston. Located in south-central Houston, the neighborhood was notorious for crime and had an impact on a young Webster, "Growing up, my grandmother stayed in the 'hood so I seen random crazy sh1t. [I saw] mad bums and crazy spazzed out motherf*ckers, I saw people looking weird, hungry, and grimey [sic]. I was always like, 'I gotta get the f*ck out this sh1t.' It gave me my edge—[it made me] who I am right now."
        </div>
        <img src="images/youngwebster.jpg" alt="yungteravis" class="travismuda">
    </main>
    <footer>
        <div class="kaili">
            <h1>Personal Life</h1>
            Scott began dating media personality and businesswoman Kylie Jenner in April 2017. In February 2018, Jenner gave birth to their daughter. Jenner appeared in the music video for "Stop Trying to Be God", from Scott's third studio album Astroworld. They broke up in September 2019, but quarantined together during the COVID-19 pandemic for the sake of their daughter and ended up rekindling their relationship. On September 7, 2021, after weeks of speculation, Jenner revealed that she and Scott were expecting their second child. Jenner gave birth to their son in February 2022. The couple separated for a second time by January 2023.
        </div>
        <img src="images/kylie&jenner.jpeg" alt="" class="kailijenner">
    </footer>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\curos\resources\views/landing/tracard.blade.php ENDPATH**/ ?>